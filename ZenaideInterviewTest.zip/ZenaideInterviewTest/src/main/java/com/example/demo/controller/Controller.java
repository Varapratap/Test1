package com.example.demo.controller;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/sampleTest")
public class Controller {
	
	@RequestMapping("/Test")
	public String getDetails(String sampleTest) {
		return "Test";
	}
	
	@GetMapping("/getAllFibo")
	public ArrayList<Integer> getAllList(){
		ArrayList<Integer> fib = new ArrayList<>();
		fib.add(0);
		fib.add(1);
		int n=10;
		for(int i=2; i<n; i++) {
			fib.add(fib.get(i-1)+fib.get(i-2));
		}
		return fib;
	}
	
			
}
