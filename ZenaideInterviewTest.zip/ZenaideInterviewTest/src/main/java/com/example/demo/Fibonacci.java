package com.example.demo;

public class Fibonacci {

	 static int testFib(int n)
	    {
	          if (n <= 1)
	            return n;
	 
	          return testFib(n - 1)
	           + testFib(n - 2);
	    }
	
	
	public static void main(String[] args) {
	 int n=10;
	 for(int i=0; i<n; i++)
	 {
		 System.out.println(testFib(i)+" ");
	 }

		}

}
